package edu.unca.csci201;

public class Diamond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t\t    *");
		System.out.println("\t\t   ***");
		System.out.println("\t\t  *****");
		System.out.println("\t\t *******");
		System.out.println("\t\t*********");
		System.out.println("\t\t *******");
		System.out.println("\t\t  *****");
		System.out.println("\t\t   ***");
		System.out.println("\t\t    *");
		
	}

}
