package edu.unca.csci201;

public class Pawn extends ChessPiece {

    public Pawn(int color) {
	super(color);
	this.abbreviation = 'P';
    }

    public Pawn(int color, String position) {
	super(color, position);
	this.abbreviation = 'P';
    }

    @Override
    public boolean validMove(String code) {
	int currCol = position.charAt(0) - 'a';
	int currRowChar = position.charAt(1) - '0';
	int currRow = 8 - currRowChar;
	
	int moveCol = code.charAt(0) - 'a';
	int moveRowChar = code.charAt(1) - '0';
	int moveRow = 8 - moveRowChar;
	if (this.getColor() == 1) {
	    return moveCol == currCol && moveRow == (currRow - 1);
	} else {
	    return moveCol == currCol && moveRow == (currRow - 1);
	}
    }

}
