package edu.unca.csci201;

public class Knight extends ChessPiece {

    public Knight(int color) {
	super(color);
	this.abbreviation = 'N';    

    }

    public Knight(int color, String position) {
	super(color, position);
	this.abbreviation = 'N';
    }

    @Override
    public boolean validMove(String code) {
	String[] Nmoves = {"-12", "12", "21", "2-1", "1-2", "-1-2", "-2-1", "-21"}; 
	int currCol = position.charAt(0) - 'a';
	int currRowChar = position.charAt(1) - '0';
	int currRow = 8 - currRowChar;
	
	int moveCol = code.charAt(0) - 'a';
	int moveRowChar = code.charAt(1) - '0';
	int moveRow = 8 - moveRowChar;
	
	int colDist = moveCol - currCol;
	int rowDist = moveRow - currRow;
	
	String moveCoords = "" + colDist + rowDist;
	for (int i = 0; i < Nmoves.length; i++) {
	    if (moveCoords.equals(Nmoves[i])) {
		return true;
	    }
	}
	return false;
    }

}
