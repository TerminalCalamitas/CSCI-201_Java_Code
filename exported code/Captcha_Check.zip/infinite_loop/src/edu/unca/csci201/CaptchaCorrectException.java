package edu.unca.csci201;

public class CaptchaCorrectException extends Exception {

    public CaptchaCorrectException() {}
    
}
